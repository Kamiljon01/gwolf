import os
import asyncio
import logging
from datetime import datetime, timezone

from dotenv import load_dotenv
from telegram import Update
from telegram.ext import (
    ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes,
    filters
)

from src.config import BotConfig
from src.store import Store
from src.jobs import schedule_jobs
from src.security import is_allowed_chat, is_admin
from src.texts import HELP_TEXT, START_TEXT

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
logger = logging.getLogger("crypto-signal-bot")

load_dotenv()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_allowed_chat(update.effective_chat.id):
        await update.message.reply_text("This chat is not authorized to use this bot.")
        return
    await update.message.reply_text(START_TEXT)

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_allowed_chat(update.effective_chat.id):
        await update.message.reply_text("Unauthorized chat.")
        return
    await update.message.reply_text(HELP_TEXT)

async def subscribe(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_allowed_chat(update.effective_chat.id):
        await update.message.reply_text("Unauthorized chat.")
        return
    await Store.add_subscriber(update.effective_chat.id)
    await update.message.reply_text("Subscribed")

async def unsubscribe(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_allowed_chat(update.effective_chat.id):
        await update.message.reply_text("Unauthorized chat.")
        return
    await Store.remove_subscriber(update.effective_chat.id)
    await update.message.reply_text("Unsubscribed")

async def status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_allowed_chat(update.effective_chat.id):
        await update.message.reply_text("Unauthorized chat.")
        return
    subs = await Store.count_subscribers()
    await update.message.reply_text(f"OK. UTC time: {datetime.now(timezone.utc).isoformat()}\\nSubscribers: {subs}")

async def setfilters(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("Admin only.")
        return
    args = context.args
    updates = {}
    for arg in args:
        if "=" in arg:
            k, v = arg.split("=", 1)
            updates[k.strip()] = v.strip()
    if updates:
        await Store.update_filters(updates)
        await update.message.reply_text(f"Updated filters: {updates}")
    else:
        await update.message.reply_text("Usage: /setfilters key=value ...")

async def watch(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("Admin only.")
        return
    if not context.args:
        await update.message.reply_text("Usage: /watch <erc20_contract_address>")
        return
    await Store.add_watch_contract(context.args[0])
    await update.message.reply_text(f"Watching {context.args[0]}")

async def unwatch(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("Admin only.")
        return
    if not context.args:
        await update.message.reply_text("Usage: /unwatch <erc20_contract_address>")
        return
    await Store.remove_watch_contract(context.args[0])
    await update.message.reply_text(f"Unwatched {context.args[0]}")

async def backtest(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not is_allowed_chat(update.effective_chat.id):
        await update.message.reply_text("Unauthorized chat.")
        return
    try:
        symbol = context.args[0]
        tf = context.args[1] if len(context.args) > 1 else "1h"
        lookback_days = int(context.args[2]) if len(context.args) > 2 else 120
    except Exception:
        await update.message.reply_text("Usage: /backtest <symbol> <tf> <lookback_days>\\nExample: /backtest BTC/USDT 1h 120")
        return
    from src.backtest import run_backtest
    report = await run_backtest(symbol, tf, lookback_days)
    await update.message.reply_text(report)

async def main():
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    if not token:
        raise RuntimeError("TELEGRAM_BOT_TOKEN is required")

    app = ApplicationBuilder().token(token).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("subscribe", subscribe))
    app.add_handler(CommandHandler("unsubscribe", unsubscribe))
    app.add_handler(CommandHandler("status", status))
    app.add_handler(CommandHandler("setfilters", setfilters))
    app.add_handler(CommandHandler("watch", watch))
    app.add_handler(CommandHandler("unwatch", unwatch))
    app.add_handler(CommandHandler("backtest", backtest))
    app.add_handler(MessageHandler(filters.COMMAND, help_cmd))

    await Store.init()
    await schedule_jobs(app.job_queue)

    logger.info("Bot started.")
    await app.run_polling(close_loop=False)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        pass
