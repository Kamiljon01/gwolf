import aiosqlite
from datetime import datetime, timedelta, timezone

DB_PATH = "bot.db"

async def ensure_alerts_table():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS alerts (
                key TEXT PRIMARY KEY,
                last_sent_ts INTEGER
            )
        """)
        await db.commit()

async def should_send_alert(key: str, cooldown_min: int) -> bool:
    await ensure_alerts_table()
    now = int(datetime.now(timezone.utc).timestamp())
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT last_sent_ts FROM alerts WHERE key=?", (key,)) as cur:
            row = await cur.fetchone()
            if not row:
                await db.execute("INSERT INTO alerts(key, last_sent_ts) VALUES(?, ?)", (key, now))
                await db.commit()
                return True
            last = int(row[0])
            if now - last >= cooldown_min * 60:
                await db.execute("UPDATE alerts SET last_sent_ts=? WHERE key=?", (now, key))
                await db.commit()
                return True
            return False
