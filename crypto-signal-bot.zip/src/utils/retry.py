import asyncio
import random

async def retry_async(fn, tries=3, base_delay=0.5, max_delay=5.0, jitter=0.2, exceptions=(Exception,)):
    last_exc = None
    for i in range(tries):
        try:
            return await fn()
        except exceptions as e:
            last_exc = e
            delay = min(max_delay, base_delay * (2 ** i))
            delay *= (1 + random.uniform(-jitter, jitter))
            await asyncio.sleep(max(0.05, delay))
    if last_exc:
        raise last_exc
