import asyncio
from time import monotonic

class TokenBucket:
    def __init__(self, rate_per_sec=5, capacity=10):
        self.rate = rate_per_sec
        self.capacity = capacity
        self.tokens = capacity
        self.timestamp = monotonic()
        self.lock = asyncio.Lock()

    async def take(self, tokens=1):
        async with self.lock:
            now = monotonic()
            elapsed = now - self.timestamp
            self.timestamp = now
            self.tokens = min(self.capacity, self.tokens + elapsed * self.rate)
            if self.tokens >= tokens:
                self.tokens -= tokens
                return True
            return False
