START_TEXT = """\
Welcome! I surface potential pumps, whale activity, and momentum across CEX/DEX,
and provide risk guidance plus a simple backtester.

No guaranteed profits. High risk. Use at your own discretion.
Type /help for commands.
"""

HELP_TEXT = """\
Commands:
/subscribe – start receiving signals
/unsubscribe – stop receiving signals
/status – show bot status
/setfilters key=value ... – update thresholds (admin only)
/watch <contract> – watch an ERC-20 contract (admin)
/unwatch <contract> – remove watch (admin)
/backtest <symbol> <tf> <lookback_days> – run simple backtest

Signals sent include:
- DEX pump alerts (price/volume spikes vs recent baseline)
- Whale transfers above your min USD threshold
- Momentum filter tags (RSI/Bollinger) to reduce noise
- Suggested stops & position sizing (not financial advice)
"""
