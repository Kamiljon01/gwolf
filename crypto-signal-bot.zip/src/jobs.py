import asyncio
from telegram.ext import ContextTypes

from .store import Store
from .modules.dex_scanner import scan_dex_and_alert
from .modules.whale_scanner import scan_whales_and_alert

async def schedule_jobs(job_queue):
    job_queue.run_repeating(dex_job, interval=120, first=10)
    job_queue.run_repeating(whale_job, interval=180, first=20)

async def dex_job(context: ContextTypes.DEFAULT_TYPE):
    subs = await Store.get_subscribers()
    if not subs:
        return
    await scan_dex_and_alert(context, subs)

async def whale_job(context: ContextTypes.DEFAULT_TYPE):
    subs = await Store.get_subscribers()
    if not subs:
        return
    await scan_whales_and_alert(context, subs)
