import aiosqlite
from typing import Dict, Any

DB_PATH = "bot.db"

class Store:
    @staticmethod
    async def init():
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("""
                CREATE TABLE IF NOT EXISTS subscribers (
                    chat_id INTEGER PRIMARY KEY
                )
            """)
            await db.execute("""
                CREATE TABLE IF NOT EXISTS kv (
                    -- generic kv
                    key TEXT PRIMARY KEY,
                    value TEXT
                )
            """)
            await db.execute("""
                CREATE TABLE IF NOT EXISTS watch_contracts (
                    contract TEXT PRIMARY KEY
                )
            """)
            await db.commit()

    @staticmethod
    async def add_subscriber(chat_id: int):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("INSERT OR IGNORE INTO subscribers(chat_id) VALUES (?)", (chat_id,))
            await db.commit()

    @staticmethod
    async def remove_subscriber(chat_id: int):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("DELETE FROM subscribers WHERE chat_id = ?", (chat_id,))
            await db.commit()

    @staticmethod
    async def get_subscribers():
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT chat_id FROM subscribers") as cur:
                rows = await cur.fetchall()
                return [r[0] for r in rows]

    @staticmethod
    async def count_subscribers() -> int:
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT COUNT(*) FROM subscribers") as cur:
                (n,) = await cur.fetchone()
                return int(n)

    @staticmethod
    async def get_filters() -> Dict[str, Any]:
        default = {
            "pump_pct": "8",
            "vol_mult": "4",
            "rsi_overbought": "72",
            "rsi_oversold": "28",
            "bb_width_min": "0.05",
            "whale_min_usd": "500000",
        }
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT key, value FROM kv") as cur:
                rows = await cur.fetchall()
                out = dict(default)
                for k, v in rows:
                    out[k] = v
                return out

    @staticmethod
    async def update_filters(updates: Dict[str, Any]):
        async with aiosqlite.connect(DB_PATH) as db:
            for k, v in updates.items():
                await db.execute("INSERT INTO kv(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, str(v)))
            await db.commit()

    @staticmethod
    async def add_watch_contract(contract: str):
        contract = contract.lower()
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("INSERT OR IGNORE INTO watch_contracts(contract) VALUES(?)", (contract,))
            await db.commit()

    @staticmethod
    async def remove_watch_contract(contract: str):
        contract = contract.lower()
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("DELETE FROM watch_contracts WHERE contract=?", (contract,))
            await db.commit()

    @staticmethod
    async def list_watch_contracts():
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT contract FROM watch_contracts") as cur:
                rows = await cur.fetchall()
                return [r[0] for r in rows]
