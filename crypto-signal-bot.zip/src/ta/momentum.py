def rsi_bb_tags(price: float):
    tags = []
    if price <= 0:
        tags.append("no-price")
        return tags
    tags.append("mom")
    return tags
