import ccxt
import pandas as pd
from datetime import datetime, timedelta, timezone

async def run_backtest(symbol: str, timeframe: str, lookback_days: int):
    exchange = ccxt.binance()
    since = int((datetime.now(timezone.utc) - timedelta(days=lookback_days)).timestamp() * 1000)
    limit = 1000
    try:
        ohlcv = exchange.fetch_ohlcv(symbol, timeframe=timeframe, since=since, limit=limit)
    except Exception as e:
        return f"Backtest error: {e}"

    if not ohlcv:
        return "No data."

    df = pd.DataFrame(ohlcv, columns=["ts","open","high","low","close","vol"])
    df["vol_med"] = df["vol"].rolling(20).median()
    df["signal"] = (df["close"] > df["close"].shift(1)*1.02) & (df["vol"] > df["vol_med"]*1.5)

    equity = 1.0
    wins = 0; losses = 0; trades = 0
    for i in range(21, len(df)):
        if not df.at[i, "signal"]:
            continue
        entry = df.at[i, "close"]
        tp = entry * 1.10
        sl = entry * 0.92
        exit_price = None
        for j in range(i+1, min(i+11, len(df))):
            if df.at[j, "low"] <= sl:
                exit_price = sl; losses += 1; break
            if df.at[j, "high"] >= tp:
                exit_price = tp; wins += 1; break
        if exit_price is None:
            exit_price = df.at[min(i+10, len(df)-1), "close"]
            if exit_price >= entry: wins += 1
            else: losses += 1
        r = (exit_price/entry - 1.0)
        equity *= (1.0 + 0.12 * r * 0.1)  # tiny allocation per trade for illustration
        trades += 1

    winrate = wins / trades * 100 if trades else 0.0
    return f"Backtest {symbol} {timeframe} over ~{lookback_days}d: trades={trades}, winrate={winrate:.1f}%, equity={equity:.2f}x (toy model)."
