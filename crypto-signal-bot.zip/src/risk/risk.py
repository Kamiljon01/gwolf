def suggest_stop_and_size(symbol: str, price: float):
    if price <= 0:
        return {"stop": 10.0, "size": 1.0}
    stop_pct = 8.0
    risk_per_trade_pct = 0.5
    size_pct = (risk_per_trade_pct / stop_pct) * 100.0
    return {"stop": stop_pct, "size": size_pct}
