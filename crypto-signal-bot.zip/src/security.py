from .config import BotConfig

def is_allowed_chat(chat_id: int) -> bool:
    if not BotConfig.ALLOWED_CHAT_IDS:
        return True
    return chat_id in BotConfig.ALLOWED_CHAT_IDS

def is_admin(user_id: int) -> bool:
    return user_id == BotConfig.ADMIN_USER_ID if BotConfig.ADMIN_USER_ID else False
