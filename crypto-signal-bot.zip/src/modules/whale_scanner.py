import asyncio
from typing import List
import aiohttp

from ..store import Store
from ..config import BotConfig

ETHERSCAN_API = "https://api.etherscan.io/api"

async def etherscan_token_transfers(contract: str, limit: int = 25):
    params = {
        "module": "account",
        "action": "tokentx",
        "contractaddress": contract,
        "page": 1,
        "offset": limit,
        "sort": "desc",
        "apikey": BotConfig.ETHERSCAN_API_KEY or ""
    }
    async with aiohttp.ClientSession() as session:
        async with session.get(ETHERSCAN_API, params=params, timeout=20) as r:
            return await r.json()

async def scan_whales_and_alert(context, chat_ids: List[int]):
    filters = await Store.get_filters()
    whale_min_usd = float(filters.get("whale_min_usd", BotConfig.WHALE_MIN_USD))
    watch = await Store.list_watch_contracts()
    if not watch:
        return

    for contract in watch:
        try:
            data = await etherscan_token_transfers(contract)
            result = data.get("result", []) if isinstance(data, dict) else []
        except Exception:
            continue

        for tx in result[:15]:
            token_symbol = tx.get("tokenSymbol") or "?"
            token_decimals = int(tx.get("tokenDecimal") or "18")
            value_raw = int(tx.get("value") or "0")
            qty = value_raw / (10 ** token_decimals)
            if qty <= 0:
                continue

            msg = (
                f"Whale transfer\\n"
                f"Token: {token_symbol}\\n"
                f"Qty: {qty:,.4f}\\n"
                f"From: {tx.get('from')}\\nTo: {tx.get('to')}\\n"
                f"Tx: https://etherscan.io/tx/{tx.get('hash')}"
            )

            for cid in chat_ids:
                try:
                    await context.bot.send_message(cid, msg, disable_web_page_preview=True)
                except Exception:
                    pass

        await asyncio.sleep(0.6)
