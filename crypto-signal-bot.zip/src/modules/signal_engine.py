from typing import Dict

def score_signal(pump_pct: float, tx_ratio: float, has_whale: bool, liquidity_ok: bool) -> float:
    # Weighted score 0..1
    s = 0.0
    s += min(1.0, pump_pct / 20.0) * 0.45      # stronger weight to price impulse
    s += min(1.0, tx_ratio / 6.0) * 0.30       # transactional momentum
    s += (0.15 if has_whale else 0.0)          # whale boost
    s += (0.10 if liquidity_ok else 0.0)       # reduce rugs with some basic liq check (if available)
    return max(0.0, min(1.0, s))
