import asyncio
from typing import List
import aiohttp

from ..store import Store
from ..config import BotConfig
from ..risk.risk import suggest_stop_and_size
from ..modules.signal_engine import score_signal
from ..store_extras import should_send_alert
from ..config import BotConfig
from ..ta.momentum import rsi_bb_tags

DEX_API = "https://api.dexscreener.com/latest/dex/search?q="

def _fmt_signal(row, tags, stop_sz, score):
    name = row.get("baseToken", {}).get("name") or "?"
    symbol = row.get("baseToken", {}).get("symbol") or "?"
    pair_link = row.get("url", "")
    price = row.get("priceUsd", "?")
    change = row.get("priceChange", {})
    ch5 = change.get("h5", "?")
    vol5m = row.get("txns", {}).get("m5", {}).get("buys", 0) + row.get("txns", {}).get("m5", {}).get("sells", 0)
    chain = row.get("chainId", "?")
    stop_txt = f"Stop {stop_sz['stop']:.2f}% | Size {stop_sz['size']:.2f}%"
    return (
        f"Pump candidate on {chain}\n"
        f"{name} ({symbol})\n"
        f"Price: ${price}\n"
        f"5m change: {ch5}% | 5m tx count: {vol5m}\n"
        f"Tags: {', '.join(tags)}\n"
        Score: {score:.2f}\n"
        f"{stop_txt}\n"
        f"{pair_link}"
    )

async def fetch_dex(query: str):
    async with aiohttp.ClientSession() as session:
        async with session.get(DEX_API + query, timeout=20) as r:
            return await r.json()

async def scan_dex_and_alert(context, chat_ids: List[int]):
    filters = await Store.get_filters()
    pump_pct = float(filters.get("pump_pct", 8))
    vol_mult = float(filters.get("vol_mult", 4))

    for chain in BotConfig.DEX_CHAINS:
        try:
            data = await fetch_dex(chain)
        except Exception:
            continue
        pairs = data.get("pairs", []) if isinstance(data, dict) else []

        for row in pairs[:150]:
            change = row.get("priceChange", {}) or {}
            ch5 = float(change.get("h5") or 0.0)
            if ch5 < pump_pct:
                continue
            tx5 = (row.get("txns", {}).get("m5", {}).get("buys", 0) + row.get("txns", {}).get("m5", {}).get("sells", 0)) or 0
            tx60 = (row.get("txns", {}).get("h1", {}).get("buys", 0) + row.get("txns", {}).get("h1", {}).get("sells", 0)) or 1
            if tx5 < vol_mult * max(1, tx60/12):
                continue

            tags = rsi_bb_tags(float(row.get("priceUsd") or 0.0))
            stop_sz = suggest_stop_and_size(symbol=row.get("baseToken", {}).get("symbol","?"), price=float(row.get("priceUsd") or 0.0))

            tx_ratio = tx5 / max(1, tx60/12)
            score = score_signal(pump_pct=ch5, tx_ratio=tx_ratio, has_whale=False, liquidity_ok=True)
            if score < float((await Store.get_filters()).get("score_threshold", 0.6)):
                continue
            key = f"dex:{row.get('pairAddress','?')}"
            if not await should_send_alert(key, int(BotConfig.ALERT_COOLDOWN_MIN)):
                continue
            msg = _fmt_signal(row, tags, stop_sz, score)
            for cid in chat_ids:
                try:
                    await context.bot.send_message(cid, msg, disable_web_page_preview=False)
                except Exception:
                    pass
        await asyncio.sleep(0.8)
