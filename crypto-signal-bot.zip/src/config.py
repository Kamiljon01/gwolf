import os

class BotConfig:
    ADMIN_USER_ID = int(os.environ.get("ADMIN_USER_ID", "0"))
    ALLOWED_CHAT_IDS = [int(x.strip()) for x in os.environ.get("ALLOWED_CHAT_IDS", "").split(",") if x.strip()]
    DEX_CHAINS = [x.strip() for x in os.environ.get("DEX_CHAINS", "ethereum,bsc,base,solana,polygon,arbitrum,avax").split(",")]
    WHALE_MIN_USD = float(os.environ.get("WHALE_MIN_USD", "500000"))
    ETHERSCAN_API_KEY = os.environ.get("ETHERSCAN_API_KEY", "")
    WHALE_ALERT_API_KEY = os.environ.get("WHALE_ALERT_API_KEY", "")
    SENTRY_DSN = os.environ.get("SENTRY_DSN", "")
    ALERT_COOLDOWN_MIN = int(os.environ.get("ALERT_COOLDOWN_MIN", "20"))
    SCORE_THRESHOLD = float(os.environ.get("SCORE_THRESHOLD", "0.6"))
