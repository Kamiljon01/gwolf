# Crypto Signal Bot (Heroku-ready)

A comprehensive Telegram bot that surfaces potential pumps, whale activity, and momentum across CEX/DEX markets, plus risk guidance and a simple backtester.
No guaranteed profits. High risk. Use at your own discretion.

## Features
- Whale transfers (ERC-20 via Etherscan; Whale Alert optional)
- DexScreener volume/price spike scans across multiple chains
- Momentum filters (RSI/Bollinger) to reduce noise
- Risk module: volatility-based position sizing suggestion & stop-loss levels
- Admin-only controls; subscription model for chats
- Backtest a simple strategy on CCXT-supported symbols
- Heroku worker dyno compatible

## Quick Start
1. Create a Telegram bot with @BotFather and copy its token.
2. (Optional) Get API keys:
   - Etherscan (for ERC-20 transfer scans)
   - Whale Alert (if you want centralized whale intel)
3. Fork/clone this project and set environment variables on Heroku:
   - TELEGRAM_BOT_TOKEN, ADMIN_USER_ID, ALLOWED_CHAT_IDS, etc.
4. Deploy to Heroku and scale a worker:
   heroku create
   heroku buildpacks:add heroku/python
   heroku config:set TELEGRAM_BOT_TOKEN=xxx ADMIN_USER_ID=123 ALLOWED_CHAT_IDS=123,456
   heroku config:set ETHERSCAN_API_KEY=xxx WHALE_ALERT_API_KEY=optional
   git push heroku main
   heroku ps:scale worker=1

### Local run
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python app.py

## Disclaimer
This software provides signals only. Crypto is highly volatile. No profits are guaranteed.
You are responsible for your decisions and compliance with all laws/regulations in your jurisdiction.
